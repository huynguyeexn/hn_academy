<?php 
   include_once 'hn_layout/huunhan.layout.header';
?>

   <!-- START PAGE -->
   <div class="hn-page">

<?php 
   include_once 'hn_layout/huunhan.layout.page-title';
?>

      <div class="hn-page-content">
         <div class="container">
            <div class="row">
               <div class="col-md-8">
                  <div class="hn-blog-post">
                     <div class="row">
                        <div class="col-12">
                           <div class="hn-post">
                              <div class="hn-post-img">
                                 <img src="hn_images/blog-img/1.jpg" alt="">
                              </div>
                              <a href="" class="hn-post-title">Top ten courses we love for you to try</a>
                              <div class="hn-post-meta">
                                 <p>By Simon Smith | March 18, 2018 | 3 comments</p>
                              </div>
                              <!-- Post Excerpt -->
                              <div class="hn-post-excerpt">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex in magni deserunt excepturi commodi enim mollitia natus qui, ipsam atque doloribus, accusamus error, sequi dolores quo. Ab reprehenderit consectetur animi.</p>
                              </div>
                              <a href="" class="btn">Read More</a>
                           </div>
                        </div>
                        <div class="col-12">
                           <div class="hn-post">
                              <div class="hn-post-img">
                                 <img src="hn_images/blog-img/1.jpg" alt="">
                              </div>
                              <a href="" class="hn-post-title">Top ten courses we love for you to try</a>
                              <div class="hn-post-meta">
                                 <p>By Simon Smith | March 18, 2018 | 3 comments</p>
                              </div>
                              <!-- Post Excerpt -->
                              <div class="hn-post-excerpt">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex in magni deserunt excepturi commodi enim mollitia natus qui, ipsam atque doloribus, accusamus error, sequi dolores quo. Ab reprehenderit consectetur animi.</p>
                              </div>
                              <a href="" class="btn">Read More</a>
                           </div>
                        </div>
                        <div class="col-12">
                           <div class="hn-post">
                              <div class="hn-post-img">
                                 <img src="hn_images/blog-img/2.jpg" alt="">
                              </div>
                              <a href="" class="hn-post-title">Top ten courses we love for you to try</a>
                              <div class="hn-post-meta">
                                 <p>By Simon Smith | March 18, 2018 | 3 comments</p>
                              </div>
                              <!-- Post Excerpt -->
                              <div class="hn-post-excerpt">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex in magni deserunt excepturi commodi enim mollitia natus qui, ipsam atque doloribus, accusamus error, sequi dolores quo. Ab reprehenderit consectetur animi.</p>
                              </div>
                              <a href="" class="btn">Read More</a>
                           </div>
                        </div>
                        <div class="col-12">
                           <div class="hn-post">
                              <div class="hn-post-img">
                                 <img src="hn_images/blog-img/3.jpg" alt="">
                              </div>
                              <a href="" class="hn-post-title">Top ten courses we love for you to try</a>
                              <div class="hn-post-meta">
                                 <p>By Simon Smith | March 18, 2018 | 3 comments</p>
                              </div>
                              <!-- Post Excerpt -->
                              <div class="hn-post-excerpt">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex in magni deserunt excepturi commodi enim mollitia natus qui, ipsam atque doloribus, accusamus error, sequi dolores quo. Ab reprehenderit consectetur animi.</p>
                              </div>
                              <a href="" class="btn">Read More</a>
                           </div>
                        </div>
                        <div class="col-12">
                           <div class="hn-post">
                              <div class="hn-post-img">
                                 <img src="hn_images/blog-img/1.jpg" alt="">
                              </div>
                              <a href="" class="hn-post-title">Top ten courses we love for you to try</a>
                              <div class="hn-post-meta">
                                 <p>By Simon Smith | March 18, 2018 | 3 comments</p>
                              </div>
                              <!-- Post Excerpt -->
                              <div class="hn-post-excerpt">
                                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex in magni deserunt excepturi commodi enim mollitia natus qui, ipsam atque doloribus, accusamus error, sequi dolores quo. Ab reprehenderit consectetur animi.</p>
                              </div>
                              <a href="" class="btn">Read More</a>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="hn-pagination">
                     <nav>
                            <ul class="pagination">
                                <li class="page-item active"><a class="page-link" href="#">01</a></li>
                                <li class="page-item"><a class="page-link" href="#">02</a></li>
                                <li class="page-item"><a class="page-link" href="#">03</a></li>
                            </ul>
                        </nav>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="hn-blog-sidebar">
                     <div class="hn-blog-search">
                        <form action="#" method="post">
                                <input type="search" name="search" id="Search" placeholder="Search">
                                <button type="submit"><i class="fas fa-search"></i></button>
                        </form>
                     </div>
                     <div class="hn-blog-categories">
                        <h5><strong>Categories</strong></h5>
                        <ul>
                           <li><a href="">Courses</a></li>
                           <li><a href="">Education</a></li>
                           <li><a href="">Teachers</a></li>
                           <li><a href="">Uncategories</a></li>
                        </ul>
                     </div>
                     <div class="hn-blog-latest-posts">
                        <h5><strong>Lastest Post</strong></h5>
                        <div class="hn-last-post">
                           <div class="hn-last-post-img">
                              <img src="hn_images/blog-img/lb-1.jpg" alt="">
                           </div>
                           <div class="hn-last-post-content">
                              <a href="">New Courses for you</a>
                              <p>March 18, 2018</p>
                           </div>
                        </div>
                        <div class="hn-last-post">
                           <div class="hn-last-post-img">
                              <img src="hn_images/blog-img/lb-3.jpg" alt="">
                           </div>
                           <div class="hn-last-post-content">
                              <a href="">New Courses for you</a>
                              <p>March 18, 2018</p>
                           </div>
                        </div>
                        <div class="hn-last-post">
                           <div class="hn-last-post-img">
                              <img src="hn_images/blog-img/lb-4.jpg" alt="">
                           </div>
                           <div class="hn-last-post-content">
                              <a href="">New Courses for you</a>
                              <p>March 18, 2018</p>
                           </div>
                        </div>
                        <div class="hn-last-post">
                           <div class="hn-last-post-img">
                              <img src="hn_images/blog-img/lb-1.jpg" alt="">
                           </div>
                           <div class="hn-last-post-content">
                              <a href="">New Courses for you</a>
                              <p>March 18, 2018</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>


         
      </div>
   </div>
   <!-- END PAGE -->

<?php 
   include_once 'hn_layout/huunhan.layout.footer';
?>